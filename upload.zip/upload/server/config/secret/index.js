module.exports = function() {
    return "super.super.secret.shhh";
}