var mongodb = require("mongodb");
var config = {
    host: "10.38.17.90",
    port: "27017"
}
var server = new mongodb.Server(config.host, config.port, {});
var connectionNoSQL = new mongodb.Db("hapy", server, {});
    //.open(function(error, client) {
    //if (error) throw error;
    // var collection = new mongodb.Collection(client, "test");
    // collection.insert({hello: ""}, {safe: true}, function(err, objects) {
    //     if (err) console.warn(err.message);
    //     if (err && err.message.indexOf("E1100 ") !== 1) {
            
    //     }
    // });
//});

module.exports = connectionNoSQL;