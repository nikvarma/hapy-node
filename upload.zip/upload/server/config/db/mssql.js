var Connection = require("tedious").Connection;

var config = {
    userName: "sa",
    password: "Password@12",
    server: "VBNL20107",
    options: { database: "hapy", instanceName: "SQLEXPRESS", localAddress: "10.38.17.90" }
}

var connectionMSSQL = new Connection(config);

connectionMSSQL.on("connect", function(err) {
    console.log(err);
});


module.exports = connectionMSSQL;