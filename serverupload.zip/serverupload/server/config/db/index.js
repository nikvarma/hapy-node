var mssql = require("./mssql");
var nosql = require("./nosql");

var config = [];


module.exports = config;