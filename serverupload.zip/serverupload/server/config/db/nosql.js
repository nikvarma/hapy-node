var configNoSQL = {
    development: {
        url: "",
        database: {
            host: "10.38.17.90",
            port: "27017",
            db: "hapy"
        },
        server: {
            host: "10.38.17.90",
            port: "3422"
        }
    },
    production: {
        url : "",
        database: {
            host: "10.38.17.90",
            port: "27017",
            db: "hapy"
        },
        server: {
            host: "10.38.17.90",
            port: "3421"
        }
    }
};

module.exports = configNoSQL;