var Connection = require("tedious").Connection;

var configMSSQL = {
    userName: "sa",
    password: "Password@123",
    server: "10.38.17.90",
    options: { encrypt: true, database: "hapy" }
}

var connection = new Connection(configMSSQL);

connection.on("connect", function(err) {
    console.log(err);
});

module.exports = configMSSQL;