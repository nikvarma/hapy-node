module.exports = function() {
    users: [
        uid, name, lname, fname, isactive, cid, isblocked, contactnumber, emailid, dnumber, duuid, disactive
    ];
}