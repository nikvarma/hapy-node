var posts = {
    getPostsById: function() {
        
    }
}