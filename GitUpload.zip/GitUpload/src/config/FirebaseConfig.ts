import { FirebaseAppConfig } from "angularfire2";

export const FirebaseConfig: FirebaseAppConfig = {
  apiKey: "AIzaSyDPHbfvuJmbTSbrioRbyiGtHFAOAsEvgyA",
  authDomain:
    "1022123729139-0lgi1hsi51g57tregbi8a57o01a1cj29.apps.googleusercontent.com",
  databaseURL: "https://movies-ba23a.firebaseio.com",
  projectId: "movies-ba23a",
  storageBucket: "movies-ba23a.appspot.com",
  messagingSenderId: "1022123729139"
};
