export const Endpoints = {
  firebase: {
    functions: "https://us-central1-movies-ba23a.cloudfunctions.net/",
    fcm: ""
  },
  api: {
    user: "http://users.api.hapy.co.in/api/",
    news: "http://news.api.hapy.co.in/api/",
    auth: "http://auth.api.hapy.co.in/api/",
    chat: "http://chat.api.hapy.co.in/api/",
    call: "http://call.api.hapy.co.in/api/",
    video: "http://video.api.hapy.co.in/api/",
    settings: "http://settings.api.hapy.co.in/api/",
    location: "http://location.api.hapy.co.in/api/",
    appsettings: "http://appsettings.api.hapy.co.in/api/",
    notification: "http://notification.api.hapy.co.in/api/"
  },
  vendor: {}
};
