import { Injectable } from "@angular/core";
import { UniqueDeviceID } from "@ionic-native/unique-device-id";
import { Api } from "../api/api";
import { Endpoints } from "../../config/Endpoints";
import { Firebase } from "@ionic-native/firebase";
import { AngularFireDatabase } from "angularfire2/database";
import { AngularFireAuth } from "angularfire2/auth";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { Storage } from "@ionic/storage";
import { Logging } from "../../models/logging";

@Injectable()
export class InitCallsProvider {
  private logging: Logging;
  constructor(
    private uniqueDeviceID: UniqueDeviceID,
    private api: Api,
    private firebase: Firebase,
    private fdb: AngularFireDatabase,
    private fauth: AngularFireAuth,
    private httpClient: HttpClient,
    private storage: Storage
  ) {
    this.logging = new Logging();
    this.logging.className = "InitCallsProvider";
  }

  InsertDeviceDetails(): void {
    // this.api
    //   .post(Endpoints.api.appsettings, {})
    //   .subscribe()
    //   .unsubscribe();
  }

  pushNotification() {
    this.firebase.subscribe("").then(res => {
      console.log(res);
    });
  }

  onNotificationOpen() {
    this.firebase
      .onNotificationOpen()
      .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log(err);
        }
      )
      .unsubscribe();
  }

  platformReady(data: any): void {
    this.logging.methodeName = "platformReady";
    this.logging.message = data.uuid;
    this.api.post(Endpoints.api.appsettings + "api/v1/logging/setlogging", this.logging);
  }

  loginToFirebase(userId: string) {
    this.logging.methodeName = "loginToFirebase";
    const httpOptions = {
      headers: new HttpHeaders({
        "auth-token": "gen-token-fromserver"
      })
    };

    this.fauth.user.subscribe(
      data => {
        if (data === null) {
          this.httpClient
            .post(
              Endpoints.firebase.functions + "generateToken",
              {
                userId: userId
              },
              httpOptions
            )
            .subscribe(
              data => {
                this.storage.set("userId", userId);
                this.storage
                  .get("userId")
                  .then(res => {
                    this.logging.message = res;
                    this.api.post(
                      Endpoints.api.appsettings + "api/v1/logging/setlogging",
                      this.logging
                    );

                    if (res.length > 20) {
                      this.fauth.auth
                        .signInWithCustomToken(data["token"])
                        .then(userData => {})
                        .catch(err => {
                          this.logging.message = err;
                          this.logging.extrainformation =
                            "Firebase token access";
                          this.api.post(
                            Endpoints.api.appsettings +
                              "api/v1/logging/setlogging",
                            this.logging
                          );
                        });
                    } else {
                      this.logging.message = "userId less than 20";
                      this.api.post(
                        Endpoints.api.appsettings + "api/v1/logging/setlogging",
                        this.logging
                      );
                    }
                  })
                  .catch(err => {
                    this.logging.message = err;
                    this.logging.extrainformation = "store userId access";
                    this.api.post(
                      Endpoints.api.appsettings + "api/v1/logging/setlogging",
                      this.logging
                    );
                  });
              },
              err => {
                this.logging.message = err;
                this.logging.extrainformation = "POST request sent error";
                this.api.post(
                  Endpoints.api.appsettings + "api/v1/logging/setlogging",
                  this.logging
                );
              }
            );
        }
      },
      err => {
        this.logging.message = err;
        this.logging.extrainformation =
          "Firebase user request sent to check is null or is not";
        this.api.post(
          Endpoints.api.appsettings + "api/v1/logging/setlogging",
          this.logging
        );
      }
    );
  }
}
