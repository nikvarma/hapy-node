import { Component, OnInit, ViewChild, AfterViewInit } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { IonicPage, NavController, Slides } from "ionic-angular";
import { MainPage } from "..";

/**
 * The Welcome Page is a splash page that quickly describes the app,
 * and then directs the user to create an account or log in.
 * If you'd like to immediately put the user onto a login/signup page,
 * we recommend not using the Welcome page.
 */
@IonicPage()
@Component({
  selector: "page-welcome",
  templateUrl: "welcome.html"
})
export class WelcomePage implements OnInit, AfterViewInit {
  userDataForm: FormGroup;
  @ViewChild(Slides) slides: Slides;
  constructor(public navCtrl: NavController) {}

  doSendOTP(): void {
    this.slideLockUnlock(1);
  }

  editMobileNumber(): void {
    this.slideLockUnlock(0);
  }

  doVerify(): void {
    this.slideLockUnlock(2);
  }

  goToHome(): void {
    this.navCtrl.push(MainPage);
  }

  slideLockUnlock(index: number): void {
    this.slides.lockSwipes(false);
    this.slides.slideTo(index);
    setTimeout(() => {
      this.slides.lockSwipes(true);
    }, 1000);
  }

  ngAfterViewInit(): void {
    this.slides.lockSwipes(true);
  }

  ngOnInit(): void {
    this.userDataForm = new FormGroup({
      ddlcountry: new FormControl(),
      txtmobilenumber: new FormControl(),
      txtusername: new FormControl(),
      txtverifyotp: new FormControl(),
      ddlday: new FormControl(),
      ddlmonth: new FormControl(),
      ddlyear: new FormControl()
    });
  }
}
