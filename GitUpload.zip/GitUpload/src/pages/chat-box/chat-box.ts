import {
  Component,
  OnInit,
  AfterContentInit,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  IonicPage,
  NavController,
  NavParams,
  ViewController,
  ActionSheetController,
  PopoverController
} from "ionic-angular";
import { AngularFireDatabase, ChildEvent } from "angularfire2/database";

import { Storage } from "@ionic/storage";
import { Observable } from "rxjs";

@IonicPage()
@Component({
  selector: "page-chat-box",
  templateUrl: "chat-box.html"
})
export class ChatBoxPage implements OnInit, AfterContentInit {
  toUserDetails = {};
  bgImage: string;
  textempty: boolean = true;
  toId: string;

  items: Observable<any[]>;

  messageTextBox: HTMLTextAreaElement;

  @ViewChild("chatboxbody", { read: ElementRef })
  chatboxbody: ElementRef;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private fdb: AngularFireDatabase,
    private storage: Storage,
    private viewCtrl: ViewController,
    private actionsheetCtrl: ActionSheetController,
    private popoverCtrl: PopoverController
  ) {
    
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad ChatBoxPage");
    this.listenMessage(this.toId);
  }

  listenMessage(toid: string): void {}

  closeChatBox(): void {
    this.viewCtrl.dismiss();
  }

  shareThings(): void {
    this.actionsheetCtrl
      .create({
        cssClass: "action-sheet chatbox-share-things",
        buttons: [
          {
            icon: "pin",
            text: "Location",
            cssClass: "location-icon-color",
            handler: () => {}
          },
          {
            icon: "images",
            text: "Image",
            cssClass: "call-icon-color",
            handler: () => {}
          },
          {
            icon: "film",
            text: "Video",
            cssClass: "video-icon-color",
            handler: () => {}
          },
          {
            icon: "document",
            text: "Document",
            cssClass: "document-icon-color",
            handler: () => {}
          }
        ]
      })
      .present();
  }

  sendMessage(): void {
    debugger;
    console.log(this.messageTextBox, this.toId);
    this.fdb.database.ref("messages/" + this.toId + "").push({
      messagetype: "text",
      message: this.messageTextBox
    });
  }

  ngOnInit(): void {
    let userId = this.storage.get("userId");
    userId.then(res => {
      this.toId = res;

      //this.listenMessage(res);
      console.log(res);
    });

    this.toUserDetails = {
      img: "assets/img/speakers/duck.jpg",
      name: "Avatar D",
      id: "121212121",
      status: "Online",
      sortname: "Avatar",
      offlineprieod: "30 h"
    };
  }

  userProfile(): void {}

  protected adjustTextarea(event: any): void {
    let textarea: any = event.target;
    textarea.style.overflow = "hidden";
    textarea.style.height = "auto";
    textarea.style.height = textarea.scrollHeight + "px";
    let hgth = textarea.style.height.replace(/px/g, "");
    if (parseInt(hgth) > 76) {
      textarea.style.height = "76px";
      textarea.style.overflow = "auto";
    }
    if (parseInt(hgth) == 46) {
      textarea.style.height = "32px";
    }

    if (textarea.value.length > 1) {
      this.textempty = false;
    } else {
      this.textempty = true;
    }
    return;
  }

  moreOption(popevent): void {
    let popover = this.popoverCtrl.create("PopoverComponent", {});
    popover.present({
      ev: popevent
    });
  }

  onHold(): void {
    console.log("okk");
  }
  
  ngAfterContentInit(): void {
    this.bgImage = "assets/img/speakers/duck.jpg";

    this.chatboxbody.nativeElement.style.backgroundImage =
      "url(" + this.bgImage + ")";
    this.chatboxbody.nativeElement.style.backgroundRepeat = "no-repeat";
    this.chatboxbody.nativeElement.style.backgroundSize = "cover";

    this.chatboxbody.nativeElement.style.backgroundAttachment = "fixed";
  }
}
