import { Component } from '@angular/core';

/**
 * Generated class for the PostControlsComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'post-controls',
  templateUrl: 'post-controls.html'
})
export class PostControlsComponent {

  text: string;

  constructor() {
    console.log('Hello PostControlsComponent Component');
    this.text = 'Hello World';
  }

}
