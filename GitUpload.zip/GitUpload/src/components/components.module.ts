import { NgModule } from "@angular/core";
import { PostControlsComponent } from "./post-controls/post-controls";
import { SmileyComponent } from "./smiley/smiley";
import { TranslateModule } from "../../node_modules/@ngx-translate/core";

@NgModule({
  declarations: [PostControlsComponent, SmileyComponent],
  imports: [TranslateModule.forChild()],
  exports: [PostControlsComponent, SmileyComponent]
})
export class ComponentsModule {}
