import { Component } from '@angular/core';

/**
 * Generated class for the SmileyComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'smiley',
  templateUrl: 'smiley.html'
})
export class SmileyComponent {

  text: string;

  constructor() {
    console.log('Hello SmileyComponent Component');
    this.text = 'Hello World';
  }

}
